module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: "mongodb://localhost:27017/shared_trip",
    TOKEN_SECRET: 'token-secret-regular-exam',
    COOKIE_NAME: 'SESSION_TOKEN',
};
